/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var backToTheStart = new Event() ;

var killedEvent = new Event(
    "killedEvent",
    "Die Zetas machen kurzen Prozess mit dir." ,
    "Möchtest du nochmal spielen?" ,
    "Die Zetas sind nicht erfreut und bringen dich auf grausame Art und Weise um, um ein Exempel zu statuieren. Deine Leiche wird in einzelnen Stücken an einem Baum aufgehangen.<br>Achja: Dein Chef feuert dich obendrauf, weil du auf Arbeit nur noch 'doof rumhängst'." ,
    [
        new EventLink( "Ja" , "Meikes Spiel macht mir voll viel Spaß." , backToTheStart )
    ] ,
    "https://coubsecure-a.akamaihd.net/get/bucket:12.21/p/coub/simple/cw_timeline_pic/924ae77dde8/718f3e5c5476d7121217e/big_1409617825_1382491656_image.jpg"
) ;

var tunnelEvent = new Event(
    "tunnelEvent",
    "Du baust den Tunnel" ,
    "Möchtest du nochmal spielen?" ,
    "Leider warst du schon als Kind im Sandkasten eine Niete. Der Tunnel stürzt über dir zusammen und deine Leiche wird nie gefunden." ,
    [
        new EventLink( "Ja" , "Meikes Spiel macht mir voll viel Spaß." , backToTheStart )
    ] ,
    "https://metrouk2.files.wordpress.com/2015/07/ad_175414534.jpg"
) ;

var firedEvent = new Event(
    "firedEvent",
    "Du wurdest gefeuert." ,
    "Möchtest du nochmal spielen?" ,
    "Du bist deiner Aussichtspflicht nicht nachgekommen. Dein Chef erfährt dies und entlässt dich unehrenhaft." ,
    [
        new EventLink( "Ja" , "Meikes Spiel macht mir voll viel Spaß." , backToTheStart )
    ] ,
    "http://www.army.mil/e2/c/images/2012/09/11/263412/size0.jpg"
) ;

var massacreEvent = new Event(
    "massacreEvent",
    "Du feuerst in die Menge!" ,
    "Möchtest du nochmal spielen?" ,
    "Bevor die Kugeln dich treffen, fallen 3 Zetas um. Die Kugeln reißen deine Schultern nach hinten, aber du fällst nicht. Die Schrottflinte feuert, fast wie von selbst, unbeirrt weiter und trifft tötlich die Herzen deiner Feinde. Doch langsam spürst auch du die Kraft aus deinem Körper weichen und du sinkst hinab in eine wohlige Wärme." ,
    [
        new EventLink( "Ja" , "Meikes Spiel macht mir voll viel Spaß." , backToTheStart )
    ] ,
    "http://www.texasescapes.com/TexasPanhandleTowns/WildoradoTexas/WildoradoTexasFarmhouse707TomJones.jpg"
) ;

var zetaEvent = new Event(
    "zetaEvent",
    "Du bist jetzt Mitglied des Zeta-Kartells." ,
    "Hilfst du beim Tunnelbau?" ,
    "Nach einiger Zeit treten deine kriminellen neuen Freunde mit einer 'ganz kleinen' Bitte an dich heran. Du sollst, gegen eine kräftige Gehaltserhöhung, ihnen bei dem Bau eines versteckten Schmuggler-Tunnels helfen." ,
    [
        new EventLink( "Ja" , "Her mit der Schaufel!" , tunnelEvent ) ,
        new EventLink( "Nein" , "Viel zu dunkel da unten." , killedEvent ) 
    ] ,
    "http://i2.cdn.turner.com/cnnnext/dam/assets/140206140253-mexican-cartel-5-horizontal-large-gallery.png"
) ;


var dealEvent = new Event(
    "dealEvent",
    "Du nimmst den Deal an." ,
    "Möchtest du dich dem Kartell anschließen?" ,
    "Du nimmst das Schweigegeld an. Deine Kooperation beeindruckt die Zetas. Du wirst gefragt ob du dich der Gruppe anschließen möchtest, da Grenzoffiziere stets hilfreich sind um illegale Tätigkeiten zu tarnen. Dir wird eine Beteiligung an den exorbitanten Gewinnen des illegalen Drogenhandels versprochen." ,
    [
        new EventLink( "Ja" , "Endlich Freunde!" , zetaEvent ) ,
        new EventLink( "Nein" , "Ich habe besser nichts mit diesen Cabrones zu tun." , killedEvent ) 
    ] ,
    "http://static5.businessinsider.com/image/55acfa702acae7c23f8b576d/a-protester-threw-a-stack-of-fake-money-at-fifa-president-sepp-blatter-during-a-press-conference.jpg"
) ;


var moneyEvent = new Event(
    "moneyEvent",
    "Die Zetas führen dich in einen dunklen Keller." ,
    "Nimmst du ein kleine Menge Schmiergeld?" ,
    "Nach ein paar Stunden körperlicher und mentaler Folter, inklusive der ein oder anderen Waterboarding Session, lassen sie dir einen letzten Ausweg aus deinem unvermeidbaren Schicksal." ,
    [
        new EventLink( "Ja" , "Meine Familie braucht das Geld." , dealEvent ) ,
        new EventLink( "Nein" , "Mit diesem Traume kann ich nicht weiterleben" , killedEvent ) 
    ] ,
    "http://static5.businessinsider.com/image/55acfa702acae7c23f8b576d/a-protester-threw-a-stack-of-fake-money-at-fifa-president-sepp-blatter-during-a-press-conference.jpg"
) ;

var planeOpenEvent = new Event(
    "planeOpenEvent",
    "Du öffnest die Plane." ,
    "Nimmst du den Deal an?" ,
    "Als du die Plane des Lieferwagens öffnest wirst du plötzlich von vier Kartellmitglieder der Zetas mit automatischen Schussgewehren bedroht. Sie zwingen dich unauffällig einzusteigen. Und bieten dir folgenden Deal an: Wenn du den Lieferwagen passieren lässt ohne den Vorfall deinem Chef zu melden werden sie dir 500.000 US Dollar für dein Schweigen bezahlen." ,
    [
        new EventLink( "Ja" , "Ich brauche das Geld für meine Familie." , dealEvent ) ,
        new EventLink( "Nein" , "Ich bin nicht korrupt." , killedEvent ) 
    ] ,
    "http://cdn.abclocal.go.com/images/ktrk/cms_exf_2007/automation/images/9430722_1280x720.jpg"
) ;

var pursuitEvent = new Event(
    "pursuitEvent",
    "Ihr verfolgt den geheimnissvollen Lieferwagen." ,
    "Legst du deine Waffe weg?" ,
    "Der Lieferwagen fährt eine halbe Stunde lang über hügelige Feldwege, bis ihr an einer kleinen Farm mitten im Nirgendwo ankommt. Ihr steigt aus dem Wagen, die klapprige Schrotflinte im Anschlag. Doch die Zetas haben euch bereits entdeckt und mit Maschinengewehren in der Hand umstellt." ,
    [
        new EventLink( "Ja" , "Sie sind schließlich in der Überzahl." , moneyEvent ) ,
        new EventLink( "Nein" , "Wenn ich sterbe, dann nicht alleine (Let's get this party started!)." , massacreEvent ) 
    ] ,
    "http://www.texasescapes.com/TexasPanhandleTowns/WildoradoTexas/WildoradoTexasFarmhouse707TomJones.jpg"
) ;

var noStopEvent = new Event(
    "noStopEvent",
    "Der Lieferwagen fährt weiter." ,
    "Informierst du deine Kollegen über deine Beobachtung?" ,
    "Doch beim Passieren fällt dir auf, dass im Rückraum ein bewaffnetes Kartellmitglied der Zetas steht." ,
    [
        new EventLink( "Ja" , "Das ist meine Pflicht." , pursuitEvent ) ,
        new EventLink( "Nein" , "Ich habe Angst." , firedEvent ) 
    ] ,
    "http://www.autofoundry.com/wp-content/uploads/2014/02/RedPickup2Feb13Rt146A1k.jpg"
) ;

var stopEvent = new Event(
    "stopEvent",
    "Der Lieferwagen hält an." ,
    "Möchtest du die Plane des Rückraums öffnen und den gesamten Lieferwagen filzen auch wenn dies mit Gefahr verbunden ist?" ,
    "Du bittest die Familie auszusteigen und dir ihre Papiere zu zeigen. Diese scheinen soweit in Ordnung zu sein. Doch plötzlich hörst du ein Geräusch aus dem Rückraum des Lieferwagens." ,
    [
        new EventLink( "Ja" , "Das ist (immernoch) meine Pflicht." , planeOpenEvent ) ,
        new EventLink( "Nein" , "Das war bestimmt nur der Wind." , firedEvent ) 
    ] ,
    "http://36.media.tumblr.com/b0d648e22902cb594be65a30f2386dfe/tumblr_mh79j69wWP1ri48nso1_500.png"
) ;

var startEvent = new Event(
    "startEvent",
    "Willkommen an der Grenze" ,
    "Es kommt ein großer Lieferwagen, welcher von einem Vater, der mit seiner Frau und einem Kind vorfährt an deinen Grenzübergang in Ciudad Juárez an. Möchtest du den Lieferwagen anhalten? " ,
    "Du bist ein amerikanischer Grenzoffizier der an der Grenze zwischen Mexiko und den Vereinigten Staaten positioniert ist. Deine Arbeit ist es die im Drogenhandel tätigen kriminellen Organisationen, welche auch Kartelle genannt werden, daran zu hindern Drogen illegal über die Grenze hinweg zu schmuggeln." ,
    [
        new EventLink( "Ja" , "Du hälst den Lieferwagen an." , stopEvent ) ,
        new EventLink( "Nein" , "Du lässt den Lieferwagen passieren." , noStopEvent ) 
    ] ,
    "http://img.welt.de/img/politik/crop100796113/5269736576-ci3x2l-w540/usa-grenze-DW-Sonstiges-San-Diego.jpg"
) ;

