/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function() {
    // height
    var screen = $.mobile.getScreenHeight();

    var header = $(".ui-header").hasClass("ui-header-fixed") ? $(".ui-header").outerHeight() - 1 : $(".ui-header").outerHeight();

    var footer = $(".ui-footer").hasClass("ui-footer-fixed") ? $(".ui-footer").outerHeight() - 1 : $(".ui-footer").outerHeight();

    var contentCurrent = $(".ui-content").outerHeight() - $(".ui-content").height();

    var content = screen - header - footer - contentCurrent;

    $(".ui-content").height(content);

    // Starting Sequence
    game.activateEvent(game.FStartEvent);
});

var game = {
    // Erstelle Events
    FLevelDepth: 1,
    FStartEvent: startEvent,
    FAktEvent: -1,
    activateEvent: function(_LinkedEvent) {
        var imgCode = "";
        var levelCode = "";
        var titleCode = "";
        var descCode = "";
        var challCode = "";
        var optionsCode = "";

        var leftPart = "<div class='content-part'>";
        // image
        imgCode = "<img src='" + _LinkedEvent.FBackImg + "' title='" + _LinkedEvent.FTitle + "' class='article-image' />";
        // leveldepth
        levelCode = "<div class='game-level'>" + this.FLevelDepth + "</div>";
        // titel
        titleCode = "<div class='article-title' >" + _LinkedEvent.FTitle + "</div>";
        // description
        descCode = "<div class='article-description'>" + _LinkedEvent.FDescription + "</div>";

        // create left part
        leftPart += imgCode + levelCode + titleCode + descCode + "</div>";

        var rightPart = "<div class='content-part'>";
        // challenge
        challCode = "<div class='article-challenge'>" + _LinkedEvent.FChallenge + "</div>";

        optionsCode = "<div class='article-buttons'>";
        // options

        for (var i = 0; i < _LinkedEvent.FLinks.length; i++) {
            if (_LinkedEvent.FLinks.length == 1) {
                optionsCode += "<a class='ui-btn option-button' onclick='window.location.reload();'>";
            } else {
                optionsCode += "<a class='ui-btn option-button' onclick='game.activateEvent(" + _LinkedEvent.FLinks [i].FLinkEvent.FName + ")'>";
            }

            optionsCode += "<div class='option-title'>" + _LinkedEvent.FLinks [i].FTitle + "</div>";
            optionsCode += "<hr>";
            optionsCode += "<div class='option-description'>" + _LinkedEvent.FLinks [i].FDescription + "</div>";
            optionsCode += "</a>";
        }
        optionsCode += "</div>";
        rightPart += challCode + optionsCode + "</div>";
        var finalCode = leftPart + rightPart;
        $("div.content-wrapper").html(finalCode);
        // Update game var
        this.FAktEvent = _LinkedEvent;
        this.FLevelDepth++;
    }

};