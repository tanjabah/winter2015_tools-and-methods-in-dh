<?php

$adventure=[];

$step1 = new stdClass();
$step1->id = 1;
$step1->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step1->text = "Du möchtest eine neue Website erstellen, welche die noch vorhandenen Bewerber bei Castingshows zeigen. Wählst du ein bestehendes CMS oder programmierst du die Seite selbst?";

$step1->option = [];
$option = new stdClass();
$option->value = "CMS";
$option->description = "Du wählst ein bestehendes CMS.";
$option->successor = 2;
$step1->option[] =$option;

$option = new stdClass();
$option->value = "Eigenentwicklung";
$option->description = "Du wählst eine Eigenentwicklung.";
$option->successor = 3;
$step1->option[] = $option;

$adventure[$step1->id] = $step1;



// 2

$step2 = new stdClass();
$step2->id = 2;
$step2->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step2->text = "Du möchtest ein bestehendes CMS nutzen. Es stehen zur Auswahl: Wordpress und ein anderes CMS.";

$step2->option = [];


$option = new stdClass();
$option->value = "Wordpress";
$option->successor = 4;
$option->description = "Du wählst Wordpress";
$step2->option[] =$option;


$option = new stdClass();
$option->value = "Anderes";
$option->description = "Du wählst ein anderes CMS.";
$option->successor = 5;
$step2->option[] = $option;

$adventure[$step2->id] = $step2;




$step3 = new stdClass();
$step3->id = 3;
$step3->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step3->text = "Du möchtest selbst ein CMS programmieren. Gute Wahl, wenn man bedenkt, dass du nicht mal weißt ob es überhaupt großartigen Traffic gibt. Wie wirst du programmieren?";

$step3->option = [];


$option = new stdClass();
$option->value = "Einfach drauf los";
$option->successor = 8;
$option->description = "";
$step3->option[] =$option;


$option = new stdClass();
$option->value = "Nach MVC";
$option->description = "";
$option->successor = 9;
$step3->option[] = $option;

$adventure[$step3->id] = $step3;










$step4 = new stdClass();
$step4->id = 4;
$step4->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step4->text = "Wordpress ist eine gute Wahl. Es ist das am meisten eingesetzte CMS der Welt und wird ständig weiter entwickelt. Es gibt kein CMS welches mehr Plugins und Themes bietet als Wordpress. Allerdings steht es im Ruf nicht geade das schnellste und sicherste System zu sein. Der näcshte Schritt wäre zu überlegen, ob du ein Theme kaufst oder selbst entwickelst.";

$step4->option = [];


$option = new stdClass();
$option->value = "Kaufen";
$option->successor = 6;
$option->description = "";
$step4->option[] =$option;


$option = new stdClass();
$option->value = "Selbst entwickeln";
$option->description = "";
$option->successor = 7;
$step4->option[] = $option;

$adventure[$step4->id] = $step4;





$step5 = new stdClass();
$step5->id = 5;
$step5->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step5->text = "Du möchtest lieber ein anderes CMS als Wordpress nutzen? Überleg es dir noch mal... Du weißt nicht, ob das überhaupt was wird, also nimm den geringsten Widerstand ;)";

$step5->option = [];


$option = new stdClass();
$option->value = "Noch mal spielen";
$option->successor = 1;
$option->description = "";
$step5->option[] =$option;


$option = new stdClass();
$option->value = "";
$option->description = "";
$option->successor = 1;
$step5->option[] = $option;

$adventure[$step5->id] = $step5;














$step6 = new stdClass();
$step6->id = 6;
$step6->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step6->text = "Ein Theme zu kaufen ist eine gute Entscheidung. Themes gibt es schon günstig und sind einfach zu unterhalten. Sollte das Projekt durchstarten, bedenke vielleicht mal ein eigenes Theme zu programmieren ;)";

$step6->option = [];


$option = new stdClass();
$option->value = "";
$option->successor = 1;
$option->description = "";
$step6->option[] =$option;


$option = new stdClass();
$option->value = "Noch mal spielen";
$option->description = "";
$option->successor = 1;
$step6->option[] = $option;

$adventure[$step6->id] = $step6;













$step7 = new stdClass();
$step7->id = 7;
$step7->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step7->text = "Du möchtest den Theme selbst erstellen. Das ist gut! Überlegst du es ohne Front-End-Frameworks wie AngularJS zu bauen oder doch lieber mit?";

$step7->option = [];


$option = new stdClass();
$option->value = "Kontrollfreak: Plain";
$option->successor = 12;
$option->description = "";
$step7->option[] =$option;


$option = new stdClass();
$option->value = "Framwooooork!";
$option->description = "";
$option->successor = 13;
$step7->option[] = $option;

$adventure[$step7->id] = $step7;










$step8 = new stdClass();
$step8->id = 8;
$step8->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step8->text = "Du programmierst einfach drauf los. Ist vielleicht nicht ganz so schlecht, so könntest du womöglich weniger Arbeit haben. Sollte dein Projekt allerdings durch die Decke gehen, hättest du doppelte Arbeit. Überdenke es besser noch mal ;)";

$step8->option = [];


$option = new stdClass();
$option->value = "OK";
$option->successor = 9;
$option->description = "";
$step8->option[] =$option;


$option = new stdClass();
$option->value = "OK OK!";
$option->description = "";
$option->successor = 9;
$step8->option[] = $option;

$adventure[$step8->id] = $step8;















$step9 = new stdClass();
$step9->id = 9;
$step9->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step9->text = "Nach dem Model-View-Controller-Konzept teilst du deine Architektur in drei Ebenen. Programmierst du die Middelware in Java oder doch PHP?";

$step9->option = [];


$option = new stdClass();
$option->value = "Java";
$option->successor = 10;
$option->description = "";
$step9->option[] =$option;


$option = new stdClass();
$option->value = "PHP";
$option->description = "";
$option->successor = 11;
$step9->option[] = $option;

$adventure[$step9->id] = $step9;







$step10 = new stdClass();
$step10->id = 10;
$step10->image = "http://www.webteam.tu-darmstadt.de/media/webteam_news/java-oracle.png";
$step10->text = "Java ist eine gute Wahl, vor allem, wenn es später erfolgreich wird. Wirst du für dein Frontend lieber direkt rendern oder doch mal AngularJS probieren?";

$step10->option = [];


$option = new stdClass();
$option->value = "Kein Angular";
$option->successor = 12;
$option->description = "";
$step10->option[] =$option;


$option = new stdClass();
$option->value = "AngularJS";
$option->description = "";
$option->successor = 13;
$step10->option[] = $option;

$adventure[$step10->id] = $step10;








$step11 = new stdClass();
$step11->id = 11;
$step11->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step11->text = "Mit PHP wirst du sicherlich weit kommen. PHP läuft auf den meisten standard Servern und kann so kostengünstig und ohne große Kenntnisse über Deployment und Container genutzt werden. Sollte din Projetk später mal durch die Decke gehen, schau dir Java und seine Frameworks an - du wirst eine Menge Performance raus holen können. Wirst du für dein Frontend lieber direkt rendern oder doch mal AngularJS probieren?";

$step11->option = [];


$option = new stdClass();
$option->value = "Kein Angular";
$option->successor = 12;
$option->description = "";
$step11->option[] =$option;


$option = new stdClass();
$option->value = "AngularJS";
$option->description = "";
$option->successor = 13;
$step11->option[] = $option;

$adventure[$step11->id] = $step11;






$step12 = new stdClass();
$step12->id = 12;
$step12->image = "http://prg.is.titech.ac.jp/wp-content/uploads/2013/09/prg-banner-201309.jpg";
$step12->text = "PROBIERE ANGULAR JS!";

$step12->option = [];


$option = new stdClass();
$option->value = "Angular";
$option->successor = 13;
$option->description = "";
$step12->option[] =$option;


$option = new stdClass();
$option->value = "AngularJS";
$option->description = "";
$option->successor = 13;
$step12->option[] = $option;

$adventure[$step12->id] = $step12;








$step12 = new stdClass();
$step12->id = 13;
$step12->image = "https://angularjs.org/img/AngularJS-large.png";
$step12->text = "Ein Hoch auf Angular JS!";

$step12->option = [];


$option = new stdClass();
$option->value = "Angular";
$option->successor = 13;
$option->description = "";
$step12->option[] =$option;


$option = new stdClass();
$option->value = "AngularJS";
$option->description = "";
$option->successor = 13;
$step12->option[] = $option;

$adventure[$step12->id] = $step12;
echo json_encode($adventure);


?>