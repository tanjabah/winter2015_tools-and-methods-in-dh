
$( document ).delegate("#start", "pageinit", function() {
 
localStorage.clear();

$("#abschicken").click(function() {
	$("#fname").show();
	$("#abschicken").show();
	$("#ppt").hide();
	
	localStorage.clear();
	
})
//START
// ENTSCHEIDUNGEN START
	$("#1").hide();	

	$("#ppt").hide();

	$("#abschicken").click(function() {
		
			var Name = document.getElementById('fname').value;

			localStorage.permname = Name;



			$("#frage").hide();
			$("#weiter").show();



			if (Name !== "Passepartout"){
						
							
						$("#ppt").show();	
						} 
						$("#1").show();	
						
						
	})
	

			
	$("#pptyes").click(function(){

	Name = "Passepartout";
	localStorage.permname = "Passepartout";
	alert("Du heißt jetzt: "+Name+"!");


	})
});
//HOME

$( document ).delegate("#home", "pageinit", function() {
  
//AUSIRKUNGEN HOME

var Name = localStorage.permname;
	$("#Spielername").html(localStorage.permname);
//Entscheidungen HOME
	$("#bleiben").click(function() {
		
		localStorage.colt = "yes";
		//alert( localStorage.colt );
		$("#park").fadeOut('fast');
		
		
	})
	$("#park").click(function() {
		
		localStorage.fly = "yes";
		//alert( localStorage.fly );
		$("#bleiben").fadeOut('fast');
	})	
	
	
	
})
	
//HOME2
	
$( document ).delegate("#home2", "pageinit", function() {
		
		
	$("#alt_balon").hide();
		
//alert(localStorage.permname);
//Auswirkungen Home2
	
	var Name = localStorage.permname;
	
	$("#Spielername2").html(localStorage.permname);
	$("#Spielername3").html(localStorage.permname);
	$("#Spielername4").html(localStorage.permname);
	
	if (localStorage.fly == "yes"){
		
		$("#alt_balon").show();
		
	}
	
})
	
//Packen 
//Auswirkungen
	
$( document ).delegate("#packen", "pageinit", function() {
		
	$("#revolver").hide();
	//alert(localStorage.colt);
	if (localStorage.colt == "yes"){
		
		$("#revolver").show();
		
	}


	//Entscheidungen

	$("#pack").click(function(){
	
		localStorage.seil = document.getElementById("seil").checked;
		console.log(localStorage.seil);
		
		localStorage.lupe = document.getElementById("lupe").checked;
		console.log(localStorage.lupe);
		
		localStorage.rev = document.getElementById("rev").checked;
		console.log(localStorage.rev);
		

	if ((localStorage.seil == "true") && (localStorage.lupe == "true") && (localStorage.rev == "true")){
			
		alert("Obwohl sie ganz Genau wissen, dass nur ZWEI dieser Gegenstände in die Tasche passen, entscheiden sie sich die Tasche zu überladen.");
			
	} else {


		alert("Sie haben die Ausgewähen Gesgenstände in der Tasche verstaut.");

	}
	});
	
	
})
//PARISREiSE

$( document ).delegate("#parisreise", "pageinit", function() {

	$("#ups").hide();
	$("#raub").hide();
	$("#geldyes").hide();
	$("#gunyes").hide();

	$("#Spielername5").html(localStorage.permname);

	if ((localStorage.seil == "true") && (localStorage.lupe == "true") && (localStorage.rev == "true")){

			$("#ups").show();
			
			localStorage.rev = "false";
			console.log(localStorage.rev);
			
	} else {
		
			$("#raub").show();
			
				if (localStorage.rev !== "true"){
					
					$("#gun").hide();
						
				}
				
			
			$("#geld").click(function() {
				$("#gun").fadeOut('fast');
				$("#geldyes").show();
			})
			
			$("#gun").click(function() {
				$("#geld").fadeOut('fast');
				$("#gunyes").show();
			})
	}

})

//BALONREISE

$( document ).delegate("#balonflug", "pageinit", function() {
	
	$("#Spielername6").html(localStorage.permname);
	$("#protest").hide();
	$("#flynow").hide();

	$("#no").click(function() {
				$("#yes").fadeOut('fast');
				$("#protest").show();
			})
	$("#yes").click(function() {
				$("#no").fadeOut('fast');
				$("#flynow").show();
			})
	})
	
	
//Sturm

$( document ).delegate("#sturm", "pageinit", function() {
	$("#Spielername7").html(localStorage.permname);
	$("#Spielername8").html(localStorage.permname);
	$("#lupewas").hide();
	$("#seilja").hide();
	$("#geld2").hide();

	if (localStorage.seil !== "true"){
		
		$("#seil2").hide();
	}
	
	if (localStorage.lupe !== "true"){
		
		$("#lupe2").hide();
	}
	
	if ((localStorage.seil !== "true") && (localStorage.lupe !== "true")){
		
		$("#geld2").show();
		
	}
	

	$("#lupe2").click(function() {
				$("#seil2").fadeOut('fast');
				$("#lupewas").show();
			})
	
	$("#geld2").click(function() {
				$("#seil2").fadeOut('fast');
				$("#lupewas").show();
			})
			
			
	$("#seil2").click(function() {
				$("#lupe2").fadeOut('fast');
				$("#seilja").show();
				localStorage.rettung = "yes";
				console.log(localStorage.rettung);
			})
})

//BERLIN
$( document ).delegate("#inberlin", "pageinit", function() {
	
	
	$("#Spielername10").html(localStorage.permname);
	$("#Spielername11").html(localStorage.permname);
	$("#Spielername12").html(localStorage.permname);
	
	$(".gerettet").hide();
	
if (localStorage.rettung == "yes"){
	//$("#gerettet2").hide();
	
	$(".gerettet").show();
	//$("#gerettet2").show();
	
}

})

//Polizist
$( document ).delegate("#polizeibahn", "pageinit", function() {

	$(".Spielername").html(localStorage.permname);
	$("#normal").hide();
	$("#franzos").hide();
	$("#Foggja").hide();
	$("#Foggnein").hide();
	if(localStorage.permname !== "Passepartout"){
		
		$("#normal").show();
		
	}
	
	if(localStorage.permname == "Passepartout"){
	//alert(localStorage.permname);
	$("#franzos").show();
		
		if (localStorage.rettung == "yes"){
			
			$("#Foggja").show();
		}else{
			
			$("#Foggnein").show();
		}
	}
})
//endentscheidung

$( document ).delegate("#endentscheidung", "pageinit", function() {
	
	$("#zep").hide();
	$(".Spielername").html(localStorage.permname);
	$("#gerettet1").hide();
	
	if (localStorage.rettung == "yes"){
		$("#gerettet1").show();
		$("#zep").show();
	}
})
