
$(document).ready(function() { 

$("#abschicken").click(function() {
	$("#fname").show();
	$("#abschicken").show();
	$("#ppt").hide();
	
	localStorage.clear();
	
})
//START
// ENTSCHEIDUNGEN START
	$("#1").hide();	

	$("#ppt").hide();

	$("#abschicken").click(function() {
		
			var Name = document.getElementById('fname').value;

			localStorage.permname = Name;



			$("#frage").hide();
			$("#weiter").show();



			if (Name !== "Passepartout"){
						
							
						$("#ppt").show();	
						} 
						$("#1").show();	
						
						
	})
	
	$(function() {
        var $selector = $('fname');



 
	})
			
	$("#pptyes").click(function(){

	Name = "Passepartout";
	localStorage.permname = "Passepartout";
	alert("Du heißt jetzt: "+Name+"!");


	})

//HOME

//AUSIRKUNGEN HOME
	$("#Spielername").html(Name);
//Entscheidungen HOME
	$("#bleiben").click(function() {
		
		var colt = true;
		//alert( colt );
		$("#park").hide();
		
		
	})
	$("#park").click(function() {
		
		var fly = true;
		//alert( fly );
		$("#bleiben").hide();
	})

	
	
	
	
	
	
	
	
	
	
	
	})
$( document ).delegate("#home", "pageinit", function() {
  alert('A page with an id of "aboutPage" was just created by jQuery Mobile!');
});